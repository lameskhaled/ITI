describe("Math utilities testing variables", () => {
  // at before all assign pos vals with array of positive numbers,
  let pos_vals = [5, 8, 4];
  // and assign negative vals with negative array of numbers,
  let neg_vals = [-8, -6];
  // assign vals to pos_vals.concat(neg_vals);
  let vals = [...pos_vals, ...neg_vals];
  // assign  sum_of_vals to vals.reduce((x, y) => x + y, 0));
  let sum_of_vals = vals.reduce((sum, current) => sum + current, 0);

  // at before each console.log all vals
  beforeEach((done) => {
    console.log(vals);
    done();
  });

  // at after each console.log done
  afterEach((done) => {
    console.log("done");
    done();
  });

  it("sum function should equal to sum of the values", () => {
    expect(sum(vals)).toBe(sum_of_vals);
  });

  it("positive function should equal to positive values", () => {
    expect(positive(vals)).toEqual(pos_vals);
  });

  // at after all set all variables to 0
  afterAll((done) => {
    pos_vals = neg_vals = vals = sum_of_vals = 0;
    console.log(pos_vals, neg_vals, vals, sum_of_vals);
    done();
  });
});
