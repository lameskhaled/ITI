let counter = {
  currentValues: function () {
    return 1;
  },
};


function sumOfValues() {
  return counter.currentValues();
}

describe("Mocking & Spying task", function () {
  //spy on counter object currentValue property and mock its implementation to equal [100]
  // expect sumOfValues is returning the right value (new mocked value 100) after mocking
  // and expect that we called the spy function for one time
  it("Testing spying....", function () {
    counter.currentValues = jasmine.createSpy('currentValues').and.returnValue(100);
    expect(sumOfValues()).toBe(100);
    expect(counter.currentValues).toHaveBeenCalledTimes(1);
  });

  // mock a function that  return number, call it twice and expect that it is called twice
  it("Testing Mocking....", function () {
    let mockingFunction = jasmine.createSpy('mockingFunction').and.returnValue(2);
    mockingFunction();
    mockingFunction();
    expect(mockingFunction).toHaveBeenCalledTimes(2);
  });
});
