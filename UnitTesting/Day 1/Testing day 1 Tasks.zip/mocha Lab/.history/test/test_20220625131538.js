const assert = chai.assert;
const expect = chai.expect;
const should = chai.should();

const createArray = (number) => {
  const myArray = Array.from(Array(number).keys());
  return myArray;
};

const capitalizeText = (input) => {
  if (typeof input !== "string") {
    throw new TypeError("parameter should be string")
  };
  return (input.toUpperCase());
};


describe("Testing Text functions...", () => {
  it('should return a string, if the parameter is a string', () => {
    assert.typeOf(capitalizeText('mohamed'), 'string');
  });

  it('should return a capitalized version of the string', () => {
    let inputTest = 'khaled';
    capitalizeText(inputTest).should.equal(inputTest.toUpperCase());
  });

  it('should throw an error if the input is a number', () => {
    expect(() => { capitalizeText(2) }).to.throw(TypeError, 'parameter should be string')
  });
});

describe("Testing array functions...", () => {
  before((done) => setTimeout(() => done(), 1500));

  it('should return an array', () => {
    assert.typeOf(createArray(2), 'array');
  });

  it('should return an array with the length of the passed input', () => {
    expect(createArray(3)).length(3).includes(1);
  });
})