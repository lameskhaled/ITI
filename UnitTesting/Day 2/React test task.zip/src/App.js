import "../node_modules/bootstrap/dist/css/bootstrap.min.css";
import "../node_modules/bootstrap/dist/js/bootstrap.min.js";
import "./App.css";

import SignInForm from "./components/SignIn/signin";

function App() {
  return (
    <div className="container-fluid min-vh-100 d-flex flex-row flex-wrap justify-content-around align-items-center">
      <SignInForm />
    </div>
  );
}

export default App;
