import { render, screen } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import SignInForm from "./signin";

function enterEmail(email) {
  const emailError = screen.getByTitle('emailError');
  const emailInput = screen.getByLabelText(/Email/i);
  
  if (!email) {
    emailError.textContent = 'You must enter your email';
  } else if (!(/^[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}$/i.test(email))) {
    emailError.textContent = 'Your email must have a valid email format: example@organization.domain';
    userEvent.type(emailInput, email);
  }
  else {
    userEvent.type(emailInput, email);
  }
  return emailInput;
}

function enterPassword(password) {
  const passwordInput = screen.getByLabelText(/Password/i);
  const passwordError = screen.getByTitle('passwordError');

  if (!password) {
    passwordError.textContent = 'You must enter your password';
  } else if ((password.length < 9)) {
    passwordError.textContent = 'Your password must be at least 8 characters length';
    userEvent.type(passwordInput, password);
  }
  else {
    userEvent.type(passwordInput, password);
  }
  return passwordInput;
}

describe("Testing SignIn form", () => {
  beforeEach(() => {
    // eslint-disable-next-line testing-library/no-render-in-setup
    render(<SignInForm />);
  });

  test("form fields should be initially empty", () => {
    expect(screen.getByLabelText("Email").value).toBe("");
    expect(screen.getByLabelText("Password").value).toBe("");
  });

  test("email is typed properly", () => {
    const mockInputValue = "basem@gmail.com";
    const emailInput = enterEmail(mockInputValue);
    expect(emailInput.value).toBe(mockInputValue);
  });


  test("Password is typed properly", () => {
    const mockInputValue = "1234567";
    const passwordInput = enterPassword(mockInputValue);
    expect(passwordInput.value).toBe(mockInputValue);
  });

  test("email is required error shows up when the email is assigned to an empty value", () => {
    expect(
      screen.queryByTitle('emailError')
    ).not.toHaveTextContent();

    enterEmail("");

    expect(
      screen.getByText('You must enter your email')
    ).toBeInTheDocument();
  });
  
  test("email is invalid error shows up when the email is assigned to an invalid value", () => {
    expect(
      screen.queryByTitle('emailError')
    ).not.toHaveTextContent();

    enterEmail("basemgmail.com");

    expect(
      screen.getByText('Your email must have a valid email format: example@organization.domain')
    ).toBeInTheDocument();
  });

  test("password is required error shows up when the email is assigned to an empty value", () => {
    expect(
      screen.queryByTitle('passwordError')
    ).not.toHaveTextContent();

    enterPassword("");

    expect(
      screen.getByText('You must enter your password')
    ).toBeInTheDocument();
  });
  
  test("password is invalid error shows up when the email is assigned to an invalid value", () => {
    expect(
      screen.queryByTitle('passwordError')
    ).not.toHaveTextContent();

    enterPassword("1234567");

    expect(
      screen.getByText('Your password must be at least 8 characters length')
    ).toBeInTheDocument();
  });


});
