import { useState } from 'react';

function SignInForm() {
  const [formState, setFormState] = useState({
    email: "",
    password: "",
  });


  const [errorState, setErrorState] = useState({
    emailError: "",
    passwordError: "",
    formError: ""
  });

  const [isFormValid, setIsFormValid] = useState(false);

  const [passwordVisibility, setPasswordVisibility] = useState({
    hide: true,
    show: false
  });

  function controlInputValue(event) {
    setFormState({ ...formState, [`${event.target.name}`]: event.target.value });
    validateInputValue(event.target.name, event.target.value);
  }


  function validateInputValue(inputName, inputValue) {
    let errors = { ...errorState };
    let isValid = true;
    switch (inputName) {
      case 'email': {
        if (inputValue.length < 1) {
          errors.emailError = "You must enter your email";
          isValid = false;
        }
        else if (!(/^[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}$/i.test(inputValue))) {
          errors.emailError = "Your email must have a valid email format: example@organization.domain"
          isValid = false;
        }
        else
          errors.emailError = "";
        break;
      }
      case 'password': {
        if (inputValue.length < 1) {
          errors.passwordError = "Your must enter your password"
          isValid = false;
        }
        else if (inputValue.length < 9) {
          errors.passwordError = "Your password must be at least 8 characters length"
          isValid = false;
        }
        else
          errors.passwordError = "";
        break;
      }
      default: { break; }
    }
    setErrorState(errors);
    setIsFormValid(isValid);
  }

  function submitForm(e) {
    e.preventDefault();
    if (isFormValid) {
      setErrorState({ ...errorState, formError: "" });
      alert(formState);
    }
    else
      setErrorState({ ...errorState, formError: "Your form is Invalid" });
  }

  function togglePasswordVisibility(e) {
    e.preventDefault();
    if (passwordVisibility.hide)
      setPasswordVisibility({ show: true, hide: false });
    else
      setPasswordVisibility({ show: false, hide: true });

  }

  return (
    <form noValidate={true} onSubmit={submitForm} className="border border-1 border-dark rounded my-5 px-3 d-flex flex-column justify-content-center">
      <div className="form-group mt-3">
        <label htmlFor="email">Email</label>
        <input type="email" className="form-control" id="email" name="email" placeholder="example@organization.domain"
          value={formState.email} onChange={controlInputValue}
        />
        <p title='emailError' className="text-danger mt-1">{errorState.emailError}</p>
      </div>

      <div className="form-group mt-3 position-relative">
        <label htmlFor="password">Password</label>
        <input type={passwordVisibility.show ? 'text' : 'password'} className="form-control" id="password" name="password" placeholder="Enter your password"
          value={formState.password} onChange={controlInputValue}
        />
        <button className="position-absolute end-0 top-0" onClick={togglePasswordVisibility}>{passwordVisibility.show ? 'Hide' : 'Show'}</button>
        <p title='passwordError' className="text-danger mt-1">{errorState.passwordError}</p>
      </div>

      <p className="text-danger mt-1 text-center">{errorState.formError}</p>

      <button type="submit" className="btn btn-primary mx-auto mt-5">Sign in</button>
    </form>);
}

export default SignInForm;