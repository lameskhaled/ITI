const express = require("express");
const server = express();
const users = [
  { id: 569, name: "Mohamed" },
  { id: 563, name: "khaled" },
  { id: 785, name: "Mahmoud" },
  { id: 866, name: "Fares" },
];

server.use(express.json());
server.use(express.urlencoded({ extended: true }));

server.get("/users", (req, res) => {
  res.json(users);
});

server.post("/updateusers/:id", (req, res) => {
  const userId = req.params.id;
  const userIndex = users.findIndex((user) => user.id == userId);
  users[userIndex].name = req.body.name;
  res.json(users[userIndex]);
});

module.exports = server.listen(3000, () =>
  console.log("Server is listening on http://localhost:3000")
);
