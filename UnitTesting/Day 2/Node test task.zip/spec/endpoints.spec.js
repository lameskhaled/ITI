const request = require("request");

describe("Wrapper", () => {
  let server;

  beforeAll((done) => {
    server = require("../server");
    done();
  });

  describe("Testing GET methods", () => {
    let data = {};

    beforeAll((done) => {
      request.get(
        "http://localhost:3000/users",
        function (error, response, body) {
          data.status = response.statusCode;
          data.body = body;
          done();
        }
      );
    });

    it("\n1. it should return a 200 status code", () => {
      expect(data.status).toEqual(200);
    });

    it("\n2. it should return a defined response body", () => {
      expect(data.body).toBeDefined();
    });

    it("\n3. it should return an array of objects in the body that contain an id and name properties", () => {
      JSON.parse(data.body).forEach((user) =>
        expect(Object.keys(user)).toEqual(
          jasmine.arrayContaining(["id", "name"])
        )
      );
    });
  });

  describe("Testing POST methods", () => {
    let data = {};
    let mockNewUser = { id: 1, name: "sameh" };

    beforeAll((done) => {
      request.post(
        "http://localhost:3000/updateusers/1",
        { json: true, body: mockNewUser },
        function (error, response, body) {
          data.status = response.statusCode;
          data.body = body;
          done();
        }
      );
    });

    it("\n1. it should return a 200 status code", () => {
      expect(data.status).toEqual(200);
    });

    it("\n2. it should return a defined response body", () => {
      expect(data.body).toBeDefined();
    });

    it("\n3. it should return the modified user data which equals the mock data", () => {
      expect(data.body).toEqual(jasmine.objectContaining(mockNewUser));
    });
  });

  afterAll((done) => {
    server.close();
    done();
  });
});
