import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root',
})
export class PostsService {
  serverAPI = 'https://jsonplaceholder.typicode.com/posts';
  constructor(private myHttpClient: HttpClient) {}
  getAllPosts() {
    return this.myHttpClient.get(this.serverAPI);
  }
  getPostById(postId: Number) {
    return this.myHttpClient.get(`${this.serverAPI}/${postId}`);
  }
}
