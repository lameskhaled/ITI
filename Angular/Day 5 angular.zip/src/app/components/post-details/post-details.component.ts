import { PostsService } from 'src/app/services/posts.service';
import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-post-details',
  templateUrl: './post-details.component.html',
  styleUrls: ['./post-details.component.css'],
})
export class PostDetailsComponent implements OnInit {
  postId:Number;
  post: any;
  constructor(
    private postsHttp: PostsService,
    private activatedRoute: ActivatedRoute
  ) {
    this.postId = activatedRoute.snapshot.params['postId'];
  }

  ngOnInit(): void {
    this.postsHttp.getPostById(this.postId).subscribe((post)=>{
      this.post = post
    });
  }
}
