import { Post } from './../../models/postsModel';
import { Component, OnInit } from '@angular/core';
import { PostsService } from 'src/app/services/posts.service';
// import {Post} from "src/app/models/postsModel"
@Component({
  selector: 'app-posts',
  templateUrl: './posts.component.html',
  styleUrls: ['./posts.component.css'],
})
export class PostsComponent implements OnInit {
  allPosts: any;
  constructor(private postHttp: PostsService) {}

  ngOnInit(): void {
    this.postHttp.getAllPosts().subscribe((posts) => {
      this.allPosts = posts;
    });
  }
}
