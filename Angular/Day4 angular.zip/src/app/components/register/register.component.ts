import { Component, EventEmitter, OnInit, Output } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css'],
})
export class RegisterComponent {
  @Output() dataSent = new EventEmitter();

  registerForm = new FormGroup({
    name: new FormControl('', [
      Validators.required,
      Validators.pattern('^[a-zA-Z ]+$'),
    ]),
    address: new FormControl('', [Validators.required]),
    phone: new FormControl('', [
      Validators.required,
      Validators.pattern('^01[0-2,5]{1}[0-9]{8}$'),
      Validators.minLength(11),
    ]),
    age: new FormControl('', [
      Validators.required,
      Validators.pattern('[0-9]+$'),
      Validators.min(18),
      Validators.max(60),
    ]),
  });

  sendData() {
    if (this.registerForm.valid) {
      let newUser = this.registerForm.value;
      this.dataSent.emit(newUser);
    } else {
    }
  }
}
