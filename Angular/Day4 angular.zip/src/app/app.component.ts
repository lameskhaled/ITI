import { Component, Input } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css'],
})
export class AppComponent {
  title = 'component-interaction';
  data: { name: String; phone: Number; address: String; age: Number }[] = [];

  recievedData(value: {
    name: String;
    phone: Number;
    address: String;
    age: Number;
  }) {
    this.data.push(value);
  }
}
