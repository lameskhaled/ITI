import { Component, EventEmitter, OnInit, Output } from '@angular/core';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css'],
})
export class RegisterComponent {
  @Output() dataSent = new EventEmitter();
  name = '';
  age = '';
  sendData() {
    let newUser ={ name: this.name, age: this.age }
    this.dataSent.emit(newUser);
    console.log(newUser);
  }
}
