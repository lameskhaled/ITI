import { ActivatedRoute, Router } from '@angular/router';
import { Component, OnInit, OnChanges } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { UsersService } from 'src/app/services/users-service';

@Component({
  selector: 'app-update-user',
  templateUrl: './update-user.component.html',
  styleUrls: ['./update-user.component.css'],
})
export class UpdateUserComponent implements OnInit, OnChanges {
  userId: any;
  userData: any = {
    name: '',
    age: '',
    email: '',
    phone: '',
    address: '',
    id: '',
  };
  // FormGroup
  userForm = new FormGroup({
    name: new FormControl('', [
      Validators.required,
      Validators.pattern('^[a-zA-Z ]+$'),
    ]),
    address: new FormControl('', [Validators.required]),
    phone: new FormControl('', [
      Validators.required,
      Validators.pattern('^01[0-2,5]{1}[0-9]{8}$'),
      Validators.minLength(11),
    ]),
    age: new FormControl('', [
      Validators.required,
      Validators.pattern('[0-9]+$'),
      Validators.min(18),
      Validators.max(60),
    ]),
    email: new FormControl('', [Validators.required, Validators.email]),
  });

  constructor(
    private userHttp: UsersService,
    private router: Router,
    private routerSnapshot: ActivatedRoute
  ) {
    //Get userId from params
    this.userId = this.routerSnapshot.snapshot.params['userId'];
    //get user data by id then set the formgroup value and the view value to the returned data
    this.userHttp.getUserById(this.userId).subscribe((userServerData) => {
      this.userData = { ...userServerData };
      this.userForm.setValue({
        name: this.userData.name,
        phone: this.userData.phone,
        age: this.userData.age,
        address: this.userData.address,
        email: this.userData.email,
      });
    });
  }
  updateUser = () => {
    this.userHttp
      .updateUser({ ...this.userForm.value, id: this.userData.id })
      .subscribe(() => {
        this.router.navigate(['/']);
      });
  };
  ngOnInit(): void {}
  ngOnChanges(): void {}
}
