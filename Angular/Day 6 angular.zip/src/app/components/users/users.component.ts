import { Router } from '@angular/router';
import { Component, OnInit } from '@angular/core';
import { UsersService } from 'src/app/services/users-service';
// import {Post} from "src/app/models/postsModel"
@Component({
  selector: 'app-users',
  templateUrl: './users.component.html',
  styleUrls: ['./users.component.css'],
})
export class UsersComponent implements OnInit {
  allUsers: any;
  constructor(private userHttp: UsersService, private router: Router) {}

  ngOnInit(): void {
    this.userHttp.getAllUsers().subscribe((users) => {
      this.allUsers = users;
    });
  }

  deleteUser = (userId: any) => {
    let id = userId;
    let deleteDialog = confirm(
      `Are you sure you want to delete the user with ID: ${id} ?`
    );
    if (deleteDialog) {
      this.userHttp.deleteUser(id).subscribe(() => {
        //refresh the component after deleting the user
        this.ngOnInit()
      });
    }
  };
}
