import { ActivatedRoute, Router } from '@angular/router';
import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { UsersService } from 'src/app/services/users-service';
@Component({
  selector: 'app-add-user',
  templateUrl: './add-user.component.html',
  styleUrls: ['./add-user.component.css'],
})
export class AddUserComponent implements OnInit {
  userForm = new FormGroup({
    name: new FormControl('', [
      Validators.required,
      Validators.pattern('^[a-zA-Z ]+$'),
    ]),
    address: new FormControl('', [Validators.required]),
    phone: new FormControl('', [
      Validators.required,
      Validators.pattern('^01[0-2,5]{1}[0-9]{8}$'),
      Validators.minLength(11),
    ]),
    age: new FormControl('', [
      Validators.required,
      Validators.pattern('[0-9]+$'),
      Validators.min(18),
      Validators.max(60),
    ]),
    email: new FormControl('', [Validators.required, Validators.email]),
  });
  constructor(private userHttp: UsersService, private router: Router) {}
  addNewUser = () => {
    this.userHttp
      .addUser({
        ...this.userForm.value,
        id: Math.floor(Math.random() * 100) + 1,
      })
      .subscribe(() => {
        this.router.navigate(['/']);
      });
  };
  ngOnInit(): void {}
}
