export interface Post {
  userId: Number;
  id: Number;
  title: String;
  body: String;
}


