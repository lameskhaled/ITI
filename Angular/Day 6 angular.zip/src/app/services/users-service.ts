import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root',
})
export class UsersService {
  serverAPI = 'http://localhost:3000/students';
  constructor(private myHttpClient: HttpClient) {}
  getAllUsers() {
    return this.myHttpClient.get(this.serverAPI);
  }
  getUserById(userId: Number) {
    return this.myHttpClient.get(`${this.serverAPI}/${userId}`);
  }
  addUser(userData: {}) {
    return this.myHttpClient.post(this.serverAPI, { ...userData });
  }
  updateUser(userData: any) {
    return this.myHttpClient.put(`${this.serverAPI}/${userData.id}`, {
      ...userData,
    });
  }
  deleteUser(userId: any) {
    return this.myHttpClient.delete(`${this.serverAPI}/${userId}`);
  }
}
