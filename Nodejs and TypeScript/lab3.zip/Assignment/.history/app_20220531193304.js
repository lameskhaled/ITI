const {Ticket} = require("./Modules/flights")


let flightObj = new Ticket(25,125,"Aswan","Cairo",new Date())
console.log(flightObj.getData())
