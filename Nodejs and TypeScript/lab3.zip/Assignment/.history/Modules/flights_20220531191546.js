class Ticket {
    constructor()
}