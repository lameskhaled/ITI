class Ticket {
    constructor(seatNumber,flightNumber,departureAirport,arrivalAirport)
}