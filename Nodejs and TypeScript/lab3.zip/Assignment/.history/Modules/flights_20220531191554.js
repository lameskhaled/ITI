class Ticket {
    constructor(seatNumber,flightNumber,)
}