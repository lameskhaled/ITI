class Ticket {
    constructor(seatNumber,)
}