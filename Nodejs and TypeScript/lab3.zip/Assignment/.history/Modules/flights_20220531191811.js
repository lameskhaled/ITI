class Ticket {
  constructor(
    seatNumber,
    flightNumber,
    departureAirport,
    arrivalAirport,
    travellingDate
  ) {
    this.seatNumber = seatNumber;
    this.flightNumber = flightNumber;
    this.departureAirport = departureAirport;
    this.arrivalAirport = arrivalAirport;
    this.travellingDate = travellingDate;
  }

  displayInfo() {
    console.log(
      `Dear Customer, your seat number is ${this.seatNumber}, your travelling date is ${this.travellingDate}. The`
    );
  }
}
