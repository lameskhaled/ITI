const flightsModel = require("./Modules/flights")


let flightObj = new flightsModel()