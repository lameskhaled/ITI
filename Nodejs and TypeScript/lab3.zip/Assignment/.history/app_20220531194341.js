const {Ticket} = require("./Modules/flights")


let firstTicket = new Ticket(25,125,"Aswan","Cairo",new Date())
firstTicket.displayInfo()

console.log(firstTicket.getData())

firstTicket.updateInfo(50)

firstTicket.displayInfo()
