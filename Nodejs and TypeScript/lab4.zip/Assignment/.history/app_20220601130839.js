const express = require("express");
const path = require("path");
const app = express();
const fs = require("fs");
//to handle JSON data
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
//add public folder that contain static files
app.use(express.static(path.join(__dirname, "/public")));//! path.join is mandatory here

// //function to read and write data to json file
const addToJson = (data) => {
  let jsonFile = fs.readFileSync("data.json", { encoding: "utf-8" });
  let jsonArray = JSON.parse(jsonFile);
  jsonArray.push({ ...data });

  fs.writeFileSync("data.json", JSON.stringify(jsonArray));
};

app.get("/", (req, res) => {
  res.sendFile(path.join(__dirname, "./view/main.html"));
});

app.get("/welcome", (req, res) => {
  res.sendFile(path.join(__dirname, "./view/welcome.html"));
});
//adding form data to json
app.post("/sendData", (req, res) => {
  addToJson(req.body);
  res.send(JSON.stringify(req.body))
  res.redirect("welcome");
});

app.get("/getData",(req,res)=>{

  let jsonFile = fs.readFileSync("data.json", { encoding: "utf-8" });
  let jsonArray = JSON.parse(jsonFile);
  res.send(jsonArray)
})

app.listen(7000, () => {});

