const { profile } = require("console")
var fs = require("fs")
var mainFile = fs.readFileSync("./Client-Side/HTML/entry.html").toString()
var ProfileFile = fs.readFileSync("./Client-Side/HTML/profile.html").toString()
var CssFile = fs.readFileSync("./Client-Side/Styles/style.css").toString()
var ScriptFile = fs.readFileSync("./Client-Side/Scripts/script.js").toString()



var icon = fs.readFileSync("./Client-Side/Icons/favicon.ico");

var http = require("http");
http.createServer((req, res)=>{
    // console.log(req.method);// favicon.ico
    // console.log(req.url);
    //#region GET
    if(req.method == "GET"){  
        switch(req.url){
            case "/entry.html":
                //default header ==> text/html
                res.setHeader("set-Cookie",["userName=sara"])
                res.setHeader("Access-control-Allow-Origin","*")
                res.write(entryFile);
            break;
            
            case "/style.css"://1
            case "/Styles/style.css"://1
            //2 ===> content-type [MIME Type]
                res.writeHead(res.statusCode, {"content-type":"text/css"} )
                res.write(CssFile);
            break;

            case "/script.js":
            case "/Scripts/script.js":
                // res.setHeader("content-type","application/javascript")
                res.writeHead(res.statusCode,{"content-type":"application/javascript"})
                res.write(ScriptFile);
            break;

            case "/2.jpg":
            case "/Images/2.jpg":
                res.setHeader("content-type","image/jpeg");
                res.write(img);
            break;

            case "/favicon.ico":
            case "/Icons/favicon.ico":
                res.setHeader("content-type","image/vnd.microsoft.icon");
                res.write(icon);
            break;

            default:
                if(req.url.includes("/profile.html")){
                    res.write(ProfileFile);
                }else{
                    res.writeHead(400,{"content-type":"text/plain"});
                    res.write("Not Found")
                }
            break;
        }
        // res.write("Hello World")
        res.end();
    }
    //#endregion
    //#region POST
    else if(req.method == "POST"){
        console.log("inside Post")
        // console.log(req.body);
        var name= "";
        req.on("data",
                function(rana){
                    // console.log(rana.toString()) //name=ahmed
                    name = rana.toString().split("=")[1]; 
                })
        req.on("end",
            function(){
                    //1-replace {useName} ==> name
                        ProfileFile=ProfileFile.replace("{userName}",name);
                        //2-write file
                        res.write(ProfileFile);
                        //  "{userName}";
                        ProfileFile=ProfileFile.replace(name,"{userName}");

                })
    }
    //#endregion
}).listen(7000,()=>{console.log("Listining on PORT 7000")})