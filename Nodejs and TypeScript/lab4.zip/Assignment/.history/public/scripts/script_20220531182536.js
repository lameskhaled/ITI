const getAllData = ()=>{
fetch("/getAllData",{body:JSON.parse()}).then(response=>console.log(response))
}