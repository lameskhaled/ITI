const getAllData = () => {
  fetch("/getAllData").then((response) => {
    return JSON.parse(response);
  }).then(data=>console.log(data))
};
