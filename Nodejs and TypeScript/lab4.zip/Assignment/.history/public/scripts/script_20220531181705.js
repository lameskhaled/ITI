const getAllData = ()=>{
    
}