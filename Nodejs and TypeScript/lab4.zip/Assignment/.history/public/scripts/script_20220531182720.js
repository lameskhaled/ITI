const getAllData = () => {
  fetch("/getAllData").then((response) => {
    return response.json();
  });
};
