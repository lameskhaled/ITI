const getAllData = ()=>{
    console.log("sdsdd")
}