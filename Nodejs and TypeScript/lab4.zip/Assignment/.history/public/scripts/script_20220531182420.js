const getAllData = ()=>{
fetch("/getAllData").then(response=>console.log(JSON.stringify(response.body)))
}