const getAllData = ()=>{
fetch("/getAllData",{}).then(response=>console.log(response))
}