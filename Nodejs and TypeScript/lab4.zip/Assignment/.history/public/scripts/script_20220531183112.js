const getAllData = () => {
  fetch("/getAllData").then((response) => {
    return response.json();
  }).then(data=>console.log(data[0]))
};
