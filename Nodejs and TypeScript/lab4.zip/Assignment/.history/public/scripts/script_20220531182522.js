const getAllData = ()=>{
fetch("/getAllData",{body:}).then(response=>console.log(response))
}