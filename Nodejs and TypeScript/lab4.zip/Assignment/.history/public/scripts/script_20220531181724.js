const getAllData = ()=>{

}