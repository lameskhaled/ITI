let dataTable = document.getElementById("data-table");
let clientsTable = document.getElementsByClassName("table")[0]

/**
 * Get all data from the server
 * transform data into json 
 * loop through each elemnt oj json and create a new table and table head for each element
 * append the data to the table
 */
const getAllData = () => {
  fetch("/getAllData")
    .then((response) => {
      return response.json();
    })
    .then((data) => {
      for (let client of data) {
        let tableRow = document.createElement("tr");
        let tempData = [client.name,client.mobileNumber,client.email,client.address]
        console.log(tempData)
        for (let i = 0; i < 4; i++) {
          let tableHead = document.createElement("th");
          tableHead.textContent = tempData[i]
          tableRow.append(tableHead)
        }
        dataTable.appendChild(tableRow)
        clientsTable.classList.remove("d-none")
 
      }
    });
};
