let dataTable = document.getElementById("data-table")

const getAllData = () => {
  fetch("/getAllData")
    .then((response) => {
      return response.json();
    })
    .then((data) => {

        for (let client of data) {
            console.log(client)
        }
    });
};
