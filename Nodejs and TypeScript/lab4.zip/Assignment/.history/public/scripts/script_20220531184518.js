let dataTable = document.getElementById("data-table");

const getAllData = () => {
  fetch("/getAllData")
    .then((response) => {
      return response.json();
    })
    .then((data) => {
      for (let client of data) {
        let tableRow = document.createElement("tr");
        for (let i = 0; i < 4; i++) {
          let tableHead = document.createElement("th");
          tableHead.appendChild(tableRow);
        }
      }
    });
};
