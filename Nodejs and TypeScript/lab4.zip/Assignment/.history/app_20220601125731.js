const express = require("express");
const path = require("path");
const app = express();
const fs = require("fs");
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(express.static(path.join(__dirname, "/public")));

// //function to read and write data to json file
const addToJson = (data) => {
  let jsonFile = fs.readFileSync("data.json", { encoding: "utf-8" });
  let jsonArray = JSON.parse(jsonFile);
  jsonArray.push({ ...data });

  fs.writeFileSync("data.json", JSON.stringify(jsonArray));
};

app.get("/", (req, res) => {
  res.sendFile(path.join(__dirname, "./view/main.html"));
});

app.get("/welcome", (req, res) => {
  res.sendFile(path.join(__dirname, "./view/welcome.html"));
});
app.post("/sendData", (req, res) => {
  addToJson(req.body);
  res.redirect("welcome");
});

app.get("/getData",(req,res)=>{})

app.listen(7000, () => {});

// //function to read and write data to json file
// const addToJson = (data) => {
//   let jsonFile = fs.readFileSync("data.json", { encoding: "utf-8" });
//   let jsonArray = JSON.parse(jsonFile);
//   jsonArray.push({ ...data });

//   fs.writeFileSync("data.json", JSON.stringify(jsonArray));
// };

// const icon = fs.readFileSync("./public/favicon.ico");

// http
//   .createServer((req, res) => {
//     //#region GET
//     if (req.method == "GET") {
//       switch (req.url) {
//         case "/":
//         case "/view/main.html":
//           res.setHeader("Access-control-Allow-Origin", "*");
//           res.write(mainFile);
//           break;

//         case "/welcome.html":
//         case "/view/welcome.html":
//           res.setHeader("Access-control-Allow-Origin", "*");
//           res.write(welcomeFile);
//           break;

//         case "/style.css":
//         case "/public/styles/style.css":
//           res.writeHead(res.statusCode, { "content-type": "text/css" });
//           res.write(CssFile);
//           break;

//         case "/script.js":
//         case "/public/scripts/script.js":
//           res.writeHead(res.statusCode, {
//             "content-type": "application/javascript",
//           });
//           res.write(ScriptFile);
//           break;

//         case "/favicon.ico":
//         case "/public/favicon.ico":
//           res.setHeader("content-type", "image/vnd.microsoft.icon");
//           res.write(icon);
//           break;

//         //get all client data from data.json
//         case "/getAllData":
//           let clientsData = fs.readFileSync("data.json", { encoding: "utf-8" });
//           res.write(clientsData);
//           break;

//         default:
//           res.write("error 404");
//           break;
//       }

//       res.end();
//     }
//     //#endregion
//     //#region POST
//     else if (req.method == "POST") {
//       let name;
//       let mobileNumber;
//       let email;
//       let address;

//       req.on("data", function (data) {
//         data = data.toString();
//         name = data
//           .split("=")[1]
//           .replace("+", " ")
//           .replace("&", " ")
//           .replace("mobileNumber", "");
//         mobileNumber = data
//           .split("=")[2]
//           .replace("+", " ")
//           .replace("&", " ")
//           .replace("email", "");
//         email = data
//           .split("=")[3]
//           .replace("+", " ")
//           .replace("&", " ")
//           .replace("%40", "@")
//           .replace("address", "");
//         address = data.split("=")[4].replace("+", " ").replace("&", " ");
//       });

//       req.on("end", function () {
//         addToJson({ name, mobileNumber, email, address });

//         newWelcomeFile = welcomeFile
//           .replace("{name}", name)
//           .replace("{mobileNumber}", mobileNumber)
//           .replace("{email}", email)
//           .replace("{address}", address);
//         res.write(newWelcomeFile);
//         res.end();
//       });
//     }
//     //#endregion
//   })
//   .listen(7000, () => {
//     console.log("Listining on PORT 7000");
//   });
