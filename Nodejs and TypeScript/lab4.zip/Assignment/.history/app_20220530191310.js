const { profile } = require("console");
var fs = require("fs");
var mainFile = fs.readFileSync("./view/main.html").toString();
var welcomeFile = fs.readFileSync("./view/welcome.html").toString();
var CssFile = fs.readFileSync("./public/styles/style.css").toString();
var ScriptFile = fs.readFileSync("./public/scripts/script.js").toString();

var icon = fs.readFileSync("./public/favicon.ico");

var http = require("http");
http
  .createServer((req, res) => {
    //#region GET
    if (req.method == "GET") {
      switch (req.url) {
        case "/":
        case "/view/main.html":
          //default header ==> text/html
          // res.setHeader("set-Cookie",["userName=sara"])
          res.setHeader("Access-control-Allow-Origin","*")
          res.write(mainFile);
          break;

        case "/welcome.html":
        case "/view/welcome.html":
          //default header ==> text/html
          // res.setHeader("set-Cookie",["userName=sara"])
          res.setHeader("Access-control-Allow-Origin","*")
          res.write(welcomeFile);
          break;

        case "/style.css": //1
        case "/public/styles/style.css": //1
          //2 ===> content-type [MIME Type]
          res.writeHead(res.statusCode, { "content-type": "text/css" });
          res.write(CssFile);
          break;

        case "/script.js":
        case "/public/scripts/script.js":
          // res.setHeader("content-type","application/javascript")
          res.writeHead(res.statusCode, {
            "content-type": "application/javascript",
          });
          res.write(ScriptFile);
          break;

        case "/favicon.ico":
        case "/public/favicon.ico":
          res.setHeader("content-type", "image/vnd.microsoft.icon");
          res.write(icon);
          break;

        default:
          res.write("error 404");
          break;
      }

      res.end();
    }
    //#endregion
    //#region POST
    else if (req.method == "POST") {
      //   switch (req.url) {
      //     case "/newClient":
        


      req.on("data", function (data) {
        console.log(data);
      });
      //       break;
      //     default:
      //       console.log("not found");
      //       break;
      //   }

      res.end()

      //   req.on("data", function (rana) {
      //     // console.log(rana.toString()) //name=ahmed
      //     name = rana.toString().split("=")[1];
      //   });
      //   req.on("end", function () {
      //     //1-replace {useName} ==> name
      //     ProfileFile = ProfileFile.replace("{userName}", name);
      //     //2-write file
      //     res.write(ProfileFile);
      //     //  "{userName}";
      //     ProfileFile = ProfileFile.replace(name, "{userName}");
      //   });
    }
    //#endregion
  })
  .listen(7000, () => {
    console.log("Listining on PORT 7000");
  });
