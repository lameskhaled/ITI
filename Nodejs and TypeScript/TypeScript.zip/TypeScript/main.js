"use strict";
exports.__esModule = true;
var Current_Account_js_1 = require("./modules/Current_Account.js");
var Saving_Account_js_1 = require("./modules/Saving_Account.js");
var current1 = new Current_Account_js_1.Current_Account(10205, 5000, 100);
var saving1 = new Saving_Account_js_1.Saving_Account(65100, 2000, 50);
console.log(current1);
console.log(saving1);

//run
//node main.js