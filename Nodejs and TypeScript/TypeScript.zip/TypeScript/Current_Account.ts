import { Account } from './modules/Account.js';
import { IAccount } from './modules/IAccount.js';


export class Current_Account extends Account implements IAccount{
    date_of_oppening: Date;
    interest_rate: number;

    constructor(_number: number, _balance: number, _rate){
        super(_number, _balance);
        this.interest_rate = _rate;
    }

    addCustomer(customer) : boolean{return true;}
    removeCustomer(customer) : boolean{return true;}
}
