"use strict";
exports.__esModule = true;
exports.IAccount = void 0;
var Account = /** @class */ (function () {
    function IAccount(_number, _balance) {
        this.accountNumber = _number;
        this.balance = _balance;
    }
    IAccount.prototype.depitAmmount = function () { return; };
    IAccount.prototype.creditAmount = function () { return; };
    IAccount.prototype.getBalance = function () {
        return this.balance;
    };
    return IAccount;
}());
exports.IAccount = IAccount;
