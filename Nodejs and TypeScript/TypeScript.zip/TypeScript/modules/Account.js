"use strict";
exports.__esModule = true;
exports.Account = void 0;
var Account = /** @class */ (function () {
    function Account(_number, _balance) {
        this.accountNumber = _number;
        this.balance = _balance;
    }
    Account.prototype.depitAmmount = function () { return; };
    Account.prototype.creditAmount = function () { return; };
    Account.prototype.getBalance = function () {
        return this.balance;
    };
    return Account;
}());
exports.Account = Account;
