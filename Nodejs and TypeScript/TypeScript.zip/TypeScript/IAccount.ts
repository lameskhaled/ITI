export interface IAccount{
    date_of_oppening: Date;
    addCustomer(customer): boolean;
    removeCustomer(customer):boolean;
}