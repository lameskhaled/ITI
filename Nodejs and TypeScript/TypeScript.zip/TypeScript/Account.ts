export class Account{
    accountNumber: number;
    balance: number;

    constructor(_number: number, _balance: number){
        this.accountNumber = _number;
        this.balance = _balance;
    }

    depitAmmount(): number{return ;}
    creditAmount(): number{return ;}
    getBalance(): number{
        return this.balance;
     }
}