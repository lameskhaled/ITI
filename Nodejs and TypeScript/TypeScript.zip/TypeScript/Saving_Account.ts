import { Account } from './modules/Account.js';
import { IAccount } from './modules/IAccount.js';

export class Saving_Account extends Account implements IAccount{
    date_of_oppening: Date;
    minemun_balance: number;

    constructor(_number: number, _balance: number, _minemum){
        super(_number, _balance);
        this.minemun_balance = _minemum;
    }

    addCustomer(customer) : boolean{return true;}
    removeCustomer(customer) : boolean{return true;}
}