import {Current_Account} from './modules/Current_Account';
import {Saving_Account} from './modules/Saving_Account';

const current1 = new Current_Account(10205, 5000, 100);
const saving1 = new Saving_Account(65100, 2000, 50);

console.log(current1);
console.log(saving1);

//run
//node main.js